#!/bin/bash
# ============================================================
# ERASMUS+ INTERAKTIF TIMELINE — Vercel Deployment
# ============================================================
# Bu scripti Hetzner sunucunda veya kendi bilgisayarinda calistir.
#
# ON KOSUL:
#   - git kurulu (git --version ile kontrol et)
#   - Node.js kurulu (node --version ile kontrol et, yoksa: sudo apt install nodejs npm -y)
#   - GitHub hesabi (ByX0000) erisimi var
#
# SONUC URL: https://erasmus-timeline.vercel.app
# ============================================================

echo "=========================================="
echo "  Erasmus+ Timeline — Vercel Deployment"
echo "=========================================="

# ---- ADIM 1: Klasor olustur ----
echo ""
echo "[1/7] Klasor hazirlaniyor..."
mkdir -p ~/erasmus-timeline
cd ~/erasmus-timeline

# ---- ADIM 2: index.html dosyasini koy ----
# ONEMLI: Indirdigin HTML dosyasini buraya kopyala!
# Dosya adi MUTLAKA "index.html" olmali!
echo "[2/7] index.html kontrol ediliyor..."

if [ ! -f "index.html" ]; then
    # Eger baska adda bir HTML dosyasi varsa otomatik yeniden adlandir
    HTML_FILE=$(ls *.html 2>/dev/null | head -1)
    if [ -n "$HTML_FILE" ]; then
        mv "$HTML_FILE" index.html
        echo "  -> '$HTML_FILE' dosyasi 'index.html' olarak yeniden adlandirildi"
    else
        echo "  !! HATA: Bu klasorde HTML dosyasi bulunamadi!"
        echo "  -> Indirdigin erasmus_interaktif_timeline.html dosyasini"
        echo "     ~/erasmus-timeline/ klasorune kopyala ve tekrar calistir."
        echo ""
        echo "  Ornek:"
        echo "    cp ~/Downloads/erasmus_interaktif_timeline.html ~/erasmus-timeline/index.html"
        exit 1
    fi
else
    echo "  -> index.html mevcut"
fi

# ---- ADIM 3: vercel.json config dosyasi olustur ----
echo "[3/7] vercel.json olusturuluyor..."

cat > vercel.json << 'VERCEL_CONFIG'
{
  "buildCommand": "",
  "outputDirectory": ".",
  "cleanUrls": true,
  "trailingSlash": false,
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cache-Control", "value": "public, max-age=3600" }
      ]
    }
  ]
}
VERCEL_CONFIG

echo "  -> vercel.json olusturuldu"

# ---- ADIM 4: Git baslat ve commit yap ----
echo "[4/7] Git hazirlaniyor..."

if [ ! -d ".git" ]; then
    git init
    echo "  -> Git basladi"
fi

git add index.html vercel.json
git commit -m "Erasmus+ KA121 Interaktif Timeline — Vercel deploy" 2>/dev/null || echo "  -> Degisiklik yok, commit atlanıyor"

# ---- ADIM 5: GitHub'a push et ----
echo "[5/7] GitHub'a push ediliyor..."

# Remote yoksa ekle
if ! git remote get-url origin &>/dev/null; then
    echo ""
    echo "  GitHub remote henuz eklenmemis."
    echo "  Asagidakilerden birini sec:"
    echo ""
    echo "  SSH ile (SSH key kuruluysa):"
    echo "    git remote add origin git@github.com:ByX0000/erasmus-timeline.git"
    echo ""
    echo "  HTTPS ile (token kullaniyorsan):"
    echo "    git remote add origin https://github.com/ByX0000/erasmus-timeline.git"
    echo ""
    echo "  Yukaridakilerden birini calistir, sonra bu scripti tekrar calistir."
    exit 1
fi

git branch -M main
git push -u origin main

echo "  -> GitHub'a push edildi"

# ---- ADIM 6: Vercel CLI kur ve deploy et ----
echo "[6/7] Vercel CLI kuruluyor ve deploy ediliyor..."

# Vercel CLI kurulu mu kontrol et
if ! command -v vercel &>/dev/null; then
    echo "  -> Vercel CLI kuruluyor..."
    npm install -g vercel
fi

echo ""
echo "  Vercel CLI ile deploy ediliyor..."
echo "  (Ilk seferde Vercel hesabina giris yapman gerekebilir)"
echo ""

vercel --prod --yes

# ---- ADIM 7: Sonuc ----
echo ""
echo "=========================================="
echo "  DEPLOYMENT TAMAMLANDI!"
echo "=========================================="
echo ""
echo "  URL'lerden birini dene:"
echo "    https://erasmus-timeline.vercel.app"
echo "    (veya Vercel'in verdigi URL'yi kullan)"
echo ""
echo "  Guncelleme icin:"
echo "    cd ~/erasmus-timeline"
echo "    # index.html duzenle"
echo "    git add . && git commit -m 'guncelleme' && git push"
echo "    vercel --prod --yes"
echo ""
echo "  Ozel domain baglamak icin:"
echo "    Vercel Dashboard → Settings → Domains"
echo "    → erasmus.7bolge7okul.education ekle"
echo "    → Hetzner DNS'te CNAME kaydi ekle:"
echo "       erasmus  CNAME  cname.vercel-dns.com"
echo ""
echo "=========================================="
